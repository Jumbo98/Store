sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(n){e.show("Custom handler invoked.")},test:function(e){return Number(e)}}});
//# sourceMappingURL=Quantity.js.map